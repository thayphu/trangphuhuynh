// Reset localStorage script
localStorage.clear();
localStorage.removeItem('initialized');
console.log('LocalStorage đã được reset. Refresh trang để khởi tạo dữ liệu mẫu mới.');
